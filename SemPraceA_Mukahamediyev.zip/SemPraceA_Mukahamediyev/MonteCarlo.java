import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MonteCarlo {
    private int countOfIterations;
    private Random random;
    private Map<Integer, Double> results;

    public MonteCarlo(int countOfIterations) {
        this.countOfIterations = countOfIterations;
        random = new Random();
    }

    public void calculate() throws IOException {
        File file;
        FileWriter fw = new FileWriter("results.csv");
        StringBuffer stringBuffer = new StringBuffer();
        int countFromPassFirstYear = 0;
        int countFromPassSecondYear = 0;
        int countFromPassThirdYear = 0;
        int countFromPassFourthYear = 0;
        int countFromPassFifthYear = 0;


        for (int i = 1; i <= countOfIterations; i++) {
            if (passFirstYear() && passSecondYear() && passThirdYear() && passFourthYear() && passFifthYear()) {
                countFromPassFirstYear++;
            }
            stringBuffer.append((double) countFromPassFirstYear / i + ",");
            if (passSecondYear() && passThirdYear() && passFourthYear() && passFifthYear()) {
                countFromPassSecondYear++;
            }
            stringBuffer.append((double) countFromPassSecondYear / i + ",");
            if (passThirdYear() && passFourthYear() && passFifthYear()) {
                countFromPassThirdYear++;
            }
            stringBuffer.append((double) countFromPassThirdYear / i + ",");
            if (passFourthYear() && passFifthYear()) {
                countFromPassFourthYear++;
            }
            stringBuffer.append((double) countFromPassFourthYear / i + ",");
            if (passFifthYear()) {
                countFromPassFifthYear++;
            }
            stringBuffer.append((double) countFromPassFifthYear / i + ",\n");

            fw.write(stringBuffer.toString());
            stringBuffer.delete(0, stringBuffer.length());
        }
        fw.close();
        Map<Integer, Double> result = new HashMap<>();
        result.put(1, (double) countFromPassFirstYear / countOfIterations);
        result.put(2, (double) countFromPassSecondYear / countOfIterations);
        result.put(3, (double) countFromPassThirdYear / countOfIterations);
        result.put(4, (double) countFromPassFourthYear / countOfIterations);
        result.put(5, (double) countFromPassFifthYear / countOfIterations);
        this.results = result;
    }

    private boolean passFirstYear() {
        while (true) {
            double randomValue = random.nextDouble();
            if (randomValue <= 0.6) return true;
            if (randomValue >= 0.7) continue;
            return false;
        }
    }

    private boolean passSecondYear() {
        while (true) {
            double randomValue = random.nextDouble();
            if (randomValue <= 0.6) return true;
            if (randomValue >= 0.7) continue;
            return false;
        }
    }

    private boolean passThirdYear() {
        while (true) {
            double randomValue = random.nextDouble();
            if (randomValue <= 0.7) return true;
            if (randomValue >= 0.8) continue;
            return false;
        }
    }

    private boolean passFourthYear() {
        while (true) {
            double randomValue = random.nextDouble();
            if (randomValue <= 0.85) return true;
            if (randomValue >= 0.9) continue;
            return false;
        }
    }

    private boolean passFifthYear() {
        while (true) {
            double randomValue = random.nextDouble();
            if (randomValue <= 0.9) return true;
        }
    }

    public Map<Integer, Double> getResults() {
        return results;
    }
}
