
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        MonteCarlo monteCarlo = new MonteCarlo(1000000);
        monteCarlo.calculate();
        Map<Integer, Double> results = monteCarlo.getResults();
        for (Map.Entry<Integer, Double> entry : results.entrySet())
            System.out.println(String.format("Student rocniku %d absolvuje studium z pravdepodobnosti %f", entry.getKey(), entry.getValue()));

    }

}
